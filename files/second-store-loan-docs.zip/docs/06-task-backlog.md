# Task Backlog: Second Store Loan

**Dibuat:** Kamis, 25 Juni 2026

Kerjakan task **satu fase per sesi AI**. Jangan minta semua sekaligus.

---

## Fase Development

### Fase 1: Setup project Flutter dan backend API

- [ ] _Tambahkan sub-task di sini_

### Fase 2: Auth, role user, dan profil

- [ ] _Tambahkan sub-task di sini_

### Fase 3: Listing kendaraan jual dan sewa

- [ ] _Tambahkan sub-task di sini_

### Fase 4: Detail kendaraan, search, filter, wishlist

- [ ] _Tambahkan sub-task di sini_

### Fase 5: Pengajuan beli dan pengajuan sewa

- [ ] _Tambahkan sub-task di sini_

### Fase 6: Dashboard seller / rental

- [ ] _Tambahkan sub-task di sini_

### Fase 7: Admin panel verifikasi listing

- [ ] _Tambahkan sub-task di sini_

### Fase 8: Riwayat transaksi dan penyempurnaan UI

- [ ] _Tambahkan sub-task di sini_

### Fase 9: Integrasi notifikasi dan deployment

- [ ] _Tambahkan sub-task di sini_


---

## Checklist Fitur MVP

- [ ] Login & Register
- [ ] Login dengan role user, seller, rental, admin
- [ ] Profil pengguna
- [ ] Listing kendaraan jual
- [ ] Listing kendaraan sewa
- [ ] Detail kendaraan lengkap
- [ ] Pencarian kendaraan
- [ ] Filter berdasarkan merek, tipe, harga, lokasi, tahun, transmisi
- [ ] Ajukan beli kendaraan
- [ ] Ajukan sewa kendaraan
- [ ] Wishlist / simpan kendaraan
- [ ] Chat / kontak penjual via tombol WhatsApp atau kontak langsung
- [ ] Upload foto kendaraan
- [ ] Dashboard seller / rental
- [ ] Kelola listing kendaraan
- [ ] Status kendaraan tersedia, terjual, disewa
- [ ] Riwayat transaksi user
- [ ] Verifikasi data listing oleh admin
- [ ] Manajemen pengguna oleh admin

---

## Cara Assign Task ke AI

Berikan prompt berikut ke AI:

```
Baca docs/01-product-brief.md, docs/03-database-schema.md, dan AI-RULES.md.
Kerjakan Fase [X] dari docs/06-task-backlog.md.
Jangan ubah modul yang sudah selesai.
```

---

## Status

| Fase | Status | Catatan |
|------|--------|---------|
| Fase 1 | ⬜ Pending | |
| Fase 2 | ⬜ Pending | |
| Fase 3 | ⬜ Pending | |
| Fase 4 | ⬜ Pending | |
| Fase 5 | ⬜ Pending | |
| Fase 6 | ⬜ Pending | |
| Fase 7 | ⬜ Pending | |
| Fase 8 | ⬜ Pending | |
| Fase 9 | ⬜ Pending | |
