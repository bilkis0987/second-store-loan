# Database Schema: Second Store Loan

**Dibuat:** Kamis, 25 Juni 2026
**Database:** MySQL

---

### Tabel: `users`

| Kolom | Tipe/Keterangan |
|-------|----------------|
| id | - |
| name | - |
| email | - |
| phone | - |
| password | - |
| role | - |
| address | - |
| photo | - |
| is_active | - |
| created_at | - |
| updated_at | - |

**Catatan:** 1-N vehicles, 1-N purchase_requests, 1-N rental_requests, 1-N wishlists

### Tabel: `vehicle_brands`

| Kolom | Tipe/Keterangan |
|-------|----------------|
| id | - |
| name | - |
| created_at | - |
| updated_at | - |

**Catatan:** 1-N vehicles

### Tabel: `vehicles`

| Kolom | Tipe/Keterangan |
|-------|----------------|
| id | - |
| owner_id | - |
| brand_id | - |
| title | - |
| slug | - |
| category | - |
| transaction_type | - |
| price | - |
| rental_price_daily | - |
| rental_price_weekly | - |
| rental_price_monthly | - |
| year | - |
| color | - |
| transmission | - |
| fuel_type | - |
| mileage | - |
| location | - |
| description | - |
| status | - |
| thumbnail | - |
| created_at | - |
| updated_at | - |

**Catatan:** milik users (owner_id), milik vehicle_brands (brand_id), 1-N vehicle_images, 1-N purchase_requests, 1-N rental_requests, 1-N wishlists, 1-N transactions

### Tabel: `vehicle_images`

| Kolom | Tipe/Keterangan |
|-------|----------------|
| id | - |
| vehicle_id | - |
| image_url | - |
| sort_order | - |
| created_at | - |
| updated_at | - |

**Catatan:** milik vehicles

### Tabel: `purchase_requests`

| Kolom | Tipe/Keterangan |
|-------|----------------|
| id | - |
| vehicle_id | - |
| user_id | - |
| message | - |
| offer_price | - |
| status | - |
| created_at | - |
| updated_at | - |

**Catatan:** milik vehicles & users

### Tabel: `rental_requests`

| Kolom | Tipe/Keterangan |
|-------|----------------|
| id | - |
| vehicle_id | - |
| user_id | - |
| rental_start_date | - |
| rental_end_date | - |
| total_days | - |
| total_price | - |
| note | - |
| status | - |
| created_at | - |
| updated_at | - |

**Catatan:** milik vehicles & users

### Tabel: `wishlists`

| Kolom | Tipe/Keterangan |
|-------|----------------|
| id | - |
| user_id | - |
| vehicle_id | - |
| created_at | - |

**Catatan:** milik users & vehicles

### Tabel: `transactions`

| Kolom | Tipe/Keterangan |
|-------|----------------|
| id | - |
| vehicle_id | - |
| buyer_id | - |
| seller_id | - |
| rental_request_id | - |
| transaction_type | - |
| amount | - |
| payment_status | - |
| transaction_status | - |
| created_at | - |
| updated_at | - |

**Catatan:** milik vehicles

### Tabel: `admin_verifications`

| Kolom | Tipe/Keterangan |
|-------|----------------|
| id | - |
| vehicle_id | - |
| admin_id | - |
| notes | - |
| status | - |
| verified_at | - |
| created_at | - |
| updated_at | - |

**Catatan:** milik vehicles, diverifikasi oleh admin (users)

---

## Relasi

users 1-N vehicles, vehicle_brands 1-N vehicles, vehicles 1-N vehicle_images, users 1-N purchase_requests, users 1-N rental_requests, vehicles 1-N purchase_requests, vehicles 1-N rental_requests, users 1-N wishlists, vehicles 1-N wishlists, vehicles 1-N transactions

---

## Konvensi

- Primary key: `id` (BIGINT UNSIGNED AUTO_INCREMENT)
- Timestamp: `created_at`, `updated_at`
- Soft delete: `deleted_at` (jika diperlukan)
- Foreign key: `{table_singular}_id`
